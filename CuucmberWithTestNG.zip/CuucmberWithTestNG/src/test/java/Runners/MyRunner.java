package Runners;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "/Users/shelendrakumar/Documents/Code/Cucumber-Automation/src/test/java/Features/Login.feature", 
glue = "StepDefination",
plugin = {
		"pretty", "html:target/cucumber.html" })
public class MyRunner extends AbstractTestNGCucumberTests{

}
