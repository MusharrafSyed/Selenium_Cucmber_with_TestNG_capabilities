package StepDefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Facebook {

	WebDriver driver;
	
	@Before
	public void setup() {
		driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
	}
	
	@After
	public void closeBrowser() {
		driver.quit();
	}
	
	@BeforeStep
	public void beforeStep() {
		System.out.println(" Step is started");
	}
	
	
	@AfterStep
	public void afterStep() {
		System.out.println(" Step is finished");
	}
	
	
	@BeforeAll
	public static void beforeAll() {
		System.out.println("VPN is connected");
	}
	
	
	@AfterAll
	public static void afterAll() {
		System.out.println("VPN is discconnected");
	}
	

	@Given("User enters invalid email and password")
	public void enterUserNameAndPassword() {
		driver.findElement(By.name("email")).sendKeys("test@test.com");
		driver.findElement(By.name("pass")).sendKeys("Password@123");
	}

	@And("User clicks on login button")
	public void clickOnLoginButton() {
		driver.findElement(By.name("login")).click();

	}

	@Then("Error message is displayed")
	public void errorMessageValidation() {
		boolean error = driver.findElement(By.xpath("//*[@id=\"loginform\"]/div[2]/div[2]")).isDisplayed();
		Assert.assertTrue(error);
	}

	@Given("user clicks on Forgotten password link")
	public void clickOnForgottenPasswordLink() {
		driver.findElement(By.linkText("Forgotten password?")).click();

	}

	@Then("Forgot password page is displayed")
	public void validateForgottenPsswordDisplayed() throws InterruptedException {
		String url = driver.getCurrentUrl();
		Thread.sleep(5000);
		Assert.assertTrue(url.equals("https://www.facebook.com/login/identify/?ctx=recover&ars=facebook_login&from_login_screen=0"));
	}
	
}