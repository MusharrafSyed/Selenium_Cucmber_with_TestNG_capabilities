package StepDefination;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OrangeHRMSteps {

	WebDriver driver = null;

	@Given("User is on Login page.")
	public void user_is_on_login_page() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@When("User enters valid username {string} and valid passoword {string}")
	public void user_enters_valid_username_and_valid_passoword(String userName, String password) {
		driver.findElement(By.name("username")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
	}

	@When("User clicks on Login button.")
	public void user_clicks_on_login_button() {
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
	}

	@Then("Home page should be displayed.")
	public void home_page_should_be_displayed() {
		String actualUrl = driver.getCurrentUrl();
		String expectedUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";

		Assert.assertEquals(expectedUrl, actualUrl);

	}

	@When("User clicks on Leave button.")
	public void user_clicks_on_leave_button() {
		driver.findElement(By.xpath("//span[text()='Leave']")).click();

	}

	@Then("Search button should be displayed.")
	public void search_button_should_be_displayed() {
		boolean isDisplayedStatus = driver.findElement(By.xpath("//button[@type=\"submit\"]")).isDisplayed();

		Assert.assertTrue(isDisplayedStatus);

	}

	@When("user clicks on User Image.")
	public void user_clicks_on_user_image() {
		driver.findElement(By.xpath("//img[@alt=\"profile picture\"]")).click();
	}

	@Then("Logout link should be displayed.")
	public void logout_link_should_be_displayed() throws InterruptedException {
		Thread.sleep(5000);
		boolean isDispalyed = driver.findElement(By.xpath("//a[text()='Logout']")).isDisplayed();
		Assert.assertTrue(isDispalyed);
	}

}
